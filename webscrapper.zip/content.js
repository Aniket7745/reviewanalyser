// Content script for Review Analyzer extension
// Scrapes Amazon product reviews from the current page

// Function to extract reviews from Amazon product page
function extractReviews() {
  const reviews = [];
  const productTitle = extractProductTitle();
  
  // Try different selectors for Amazon review containers
  const reviewSelectors = [
    '[data-hook="review"]',
    '.review',
    '.a-section.review',
    '[data-csa-c-type="review"]'
  ];
  
  let reviewElements = [];
  
  // Find review elements using different selectors
  for (const selector of reviewSelectors) {
    reviewElements = document.querySelectorAll(selector);
    if (reviewElements.length > 0) {
      console.log(`Found ${reviewElements.length} reviews using selector: ${selector}`);
      break;
    }
  }
  
  // If no reviews found with specific selectors, try a broader approach
  if (reviewElements.length === 0) {
    // Look for elements containing review text
    const allElements = document.querySelectorAll('*');
    reviewElements = Array.from(allElements).filter(element => {
      const text = element.textContent || '';
      return text.includes('stars') || text.includes('rating') || 
             (text.length > 50 && text.length < 1000 && 
              (text.includes('good') || text.includes('bad') || text.includes('great') || text.includes('terrible')));
    });
  }
  
  // Extract review data
  reviewElements.forEach((element, index) => {
    if (index >= 10) return; // Limit to first 10 reviews to avoid token limits
    
    const reviewText = extractReviewText(element);
    const rating = extractRating(element);
    
    if (reviewText && reviewText.length > 10) {
      reviews.push({
        text: reviewText,
        rating: rating || 0
      });
    }
  });
  
  return {
    reviews,
    productTitle
  };
}

// Function to extract product title
function extractProductTitle() {
  const titleSelectors = [
    '#productTitle',
    '.product-title',
    'h1[data-automation-id="product-title"]',
    '.a-size-large.product-title-word-break'
  ];
  
  for (const selector of titleSelectors) {
    const element = document.querySelector(selector);
    if (element) {
      return element.textContent.trim();
    }
  }
  
  return 'Unknown Product';
}

// Function to extract review text
function extractReviewText(element) {
  // Try different selectors for review text
  const textSelectors = [
    '[data-hook="review-body"]',
    '.review-text',
    '.a-expander-content',
    '.a-size-base.review-text',
    'span[data-hook="review-body"]'
  ];
  
  for (const selector of textSelectors) {
    const textElement = element.querySelector(selector);
    if (textElement) {
      let text = textElement.textContent.trim();
      // Clean up the text
      text = text.replace(/\s+/g, ' ').replace(/\n+/g, ' ');
      return text;
    }
  }
  
  // If no specific text element found, try to get text from the element itself
  let text = element.textContent || '';
  // Clean up and limit length
  text = text.replace(/\s+/g, ' ').replace(/\n+/g, ' ').trim();
  
  // If text is too long, try to find a reasonable portion
  if (text.length > 500) {
    const sentences = text.split(/[.!?]+/);
    text = sentences.slice(0, 3).join('. ') + '.';
  }
  
  return text;
}

// Function to extract rating
function extractRating(element) {
  // Try different selectors for rating
  const ratingSelectors = [
    '[data-hook="review-star-rating"]',
    '.a-icon-alt',
    '.review-rating',
    'i[class*="star"]'
  ];
  
  for (const selector of ratingSelectors) {
    const ratingElement = element.querySelector(selector);
    if (ratingElement) {
      const text = ratingElement.textContent || '';
      const match = text.match(/(\d+(?:\.\d+)?)\s*out\s*of\s*5/);
      if (match) {
        return parseFloat(match[1]);
      }
      
      // Try to find just the number
      const numberMatch = text.match(/(\d+(?:\.\d+)?)/);
      if (numberMatch) {
        const rating = parseFloat(numberMatch[1]);
        if (rating >= 1 && rating <= 5) {
          return rating;
        }
      }
    }
  }
  
  return 0; // Default rating if not found
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "extractReviews") {
    try {
      const data = extractReviews();
      sendResponse({ success: true, data });
    } catch (error) {
      console.error('Error extracting reviews:', error);
      sendResponse({ success: false, error: error.message });
    }
  }
});

// Log when content script loads
console.log('Review Analyzer content script loaded');
