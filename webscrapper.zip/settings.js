// Settings script for Review Analyzer extension
// Handles API key management and validation

document.addEventListener('DOMContentLoaded', function() {
    // Get DOM elements
    const apiKeyInput = document.getElementById('apiKey');
    const togglePasswordBtn = document.getElementById('togglePassword');
    const saveBtn = document.getElementById('saveBtn');
    const testBtn = document.getElementById('testBtn');
    const backBtn = document.getElementById('backBtn');
    const statusText = document.getElementById('statusText');
    const status = document.getElementById('status');
    
    // Load saved API key on page load
    loadApiKey();
    
    // Event listeners
    togglePasswordBtn.addEventListener('click', togglePasswordVisibility);
    saveBtn.addEventListener('click', saveApiKey);
    testBtn.addEventListener('click', testApiKey);
    backBtn.addEventListener('click', goBack);
    
    // Function to load saved API key
    async function loadApiKey() {
        try {
            const response = await chrome.runtime.sendMessage({ action: 'getApiKey' });
            if (response.apiKey) {
                apiKeyInput.value = response.apiKey;
                updateStatus('API key loaded', 'success');
            } else {
                updateStatus('No API key found. Please enter your OpenAI API key.', 'error');
            }
        } catch (error) {
            console.error('Error loading API key:', error);
            updateStatus('Error loading API key', 'error');
        }
    }
    
    // Function to toggle password visibility
    function togglePasswordVisibility() {
        const type = apiKeyInput.type === 'password' ? 'text' : 'password';
        apiKeyInput.type = type;
        togglePasswordBtn.textContent = type === 'password' ? '👁️' : '🙈';
    }
    
    // Function to save API key
    async function saveApiKey() {
        const apiKey = apiKeyInput.value.trim();
        
        if (!apiKey) {
            updateStatus('Please enter an API key', 'error');
            return;
        }
        
        if (!isValidApiKey(apiKey)) {
            updateStatus('Invalid API key format. Should start with "sk-"', 'error');
            return;
        }
        
        try {
            setLoadingState(true);
            updateStatus('Saving API key...', 'loading');
            
            const response = await chrome.runtime.sendMessage({ 
                action: 'setApiKey', 
                apiKey: apiKey 
            });
            
            if (response.success) {
                updateStatus('API key saved successfully!', 'success');
                // Notify popup that API key was updated
                chrome.runtime.sendMessage({ action: 'apiKeyUpdated' });
            } else {
                updateStatus('Failed to save API key', 'error');
            }
        } catch (error) {
            console.error('Error saving API key:', error);
            updateStatus('Error saving API key', 'error');
        } finally {
            setLoadingState(false);
        }
    }
    
    // Function to test API key
    async function testApiKey() {
        const apiKey = apiKeyInput.value.trim();
        
        if (!apiKey) {
            updateStatus('Please enter an API key first', 'error');
            return;
        }
        
        if (!isValidApiKey(apiKey)) {
            updateStatus('Invalid API key format', 'error');
            return;
        }
        
        try {
            setLoadingState(true);
            updateStatus('Testing API key...', 'loading');
            
            // Test the API key with a simple request
            const response = await fetch('https://api.openai.com/v1/models', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${apiKey}`,
                    'Content-Type': 'application/json'
                }
            });
            
            if (response.ok) {
                updateStatus('API key is valid! You can now use the extension.', 'success');
            } else {
                const errorData = await response.json();
                updateStatus(`API key test failed: ${errorData.error?.message || 'Unknown error'}`, 'error');
            }
        } catch (error) {
            console.error('Error testing API key:', error);
            updateStatus('Error testing API key. Please check your internet connection.', 'error');
        } finally {
            setLoadingState(false);
        }
    }
    
    // Function to validate API key format
    function isValidApiKey(apiKey) {
        // OpenAI API keys typically start with "sk-" and are 51 characters long
        return apiKey.startsWith('sk-') && apiKey.length >= 20;
    }
    
    // Function to set loading state
    function setLoadingState(loading) {
        saveBtn.disabled = loading;
        testBtn.disabled = loading;
    }
    
    // Function to update status
    function updateStatus(message, type) {
        statusText.textContent = message;
        
        // Remove all status classes
        status.classList.remove('success', 'error', 'loading');
        
        // Add appropriate class
        if (type) {
            status.classList.add(type);
        }
    }
    
    // Function to go back to extension
    function goBack() {
        window.close();
    }
    
    // Auto-save on input change (with debounce)
    let saveTimeout;
    apiKeyInput.addEventListener('input', function() {
        clearTimeout(saveTimeout);
        saveTimeout = setTimeout(() => {
            const apiKey = apiKeyInput.value.trim();
            if (apiKey && isValidApiKey(apiKey)) {
                updateStatus('API key format looks good', 'success');
            } else if (apiKey) {
                updateStatus('Invalid API key format', 'error');
            } else {
                updateStatus('Ready to save', '');
            }
        }, 500);
    });
    
    // Handle Enter key in input field
    apiKeyInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            saveApiKey();
        }
    });
});
