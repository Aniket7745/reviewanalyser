// Background script for Review Scraper extension
// Handles basic extension functionality

// Handle extension installation
chrome.runtime.onInstalled.addListener(() => {
  console.log('Review Scraper extension installed');
});
